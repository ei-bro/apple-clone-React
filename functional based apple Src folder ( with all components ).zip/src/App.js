import React from "react";
import Header from "./components/Header/Header.js";
// import FooterG from "./components/FooterG.js"; // work with group (footer part)
import Footer from "./components/Footer/Footer";
import Alert from "./components/mainSection/Alert";
import FirstSection from "./components/mainSection/FirstSec";
import SecondSection from "./components/mainSection/SecontSec";
import ThirdSection from "./components/mainSection/ThirdSec";
import FourthSection from "./components/mainSection/FourthSec";
import FifthSection from "./components/mainSection/FifthSec";
import SixthSection from "./components/mainSection/SixthSec";
export default function App() {
    return (
        <div>
            <Header />
            <Alert />
            <FirstSection />
            <SecondSection />
            <ThirdSection />
            <FourthSection />
            <FifthSection />
            <SixthSection />
            <Footer />
        </div>
    );
}
